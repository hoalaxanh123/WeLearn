from django.urls import path
from . import views

urlpatterns = [
    path('python',views.ListSubject),
    path('CSharp',views.CSharp),
    path('CPP',views.CPP),
    path('Java',views.JAVA),
    path('PHP',views.PHP),
    path('ASP',views.ASP),
]
