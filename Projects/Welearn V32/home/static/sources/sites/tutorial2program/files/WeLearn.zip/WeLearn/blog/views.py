from django.shortcuts import render
from .models import *
# Create your views here.
def ListSubject(request):
    Data = {'Subjects':Subject.objects.all().order_by('-dateCreate')}

    return render(request,'learn/python.html',Data) 
def CSharp(request):
    return render(request,'learn/csharp.html') 
def CPP(request):
    return render(request,'learn/cpp.html') 
def JAVA(request):
    return render(request,'learn/java.html') 
def PHP(request):
    return render(request,'learn/PHP.html') 
def ASP(request):
    return render(request,'learn/ASP.html') 